/***************************************************************************
The copyright in this software is being made available under the BSD
License, included below. This software may be subject to other third party
and contributor rights, including patent rights, and no such rights are
granted under this license.

Copyright (c) 2010, NEC CORPORATION 
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
notice,
   this list of conditions and the following disclaimer in the
documentation
   and/or other materials provided with the distribution.
 * Neither the name of the <ORGANIZATION> nor the names of its
   contributors may be used to endorse or promote products derived from
this
   software without specific prior written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
****************************************************************************/ 

/*
*
*  Usage
*  =======
   This code computes BD-PSNR/Rate based on JCTVC-A031.

   Input: 2 data files. The data file format is described below. The data file shall contain 5 rate points as follows:

     <R1 Bitrate> <R1 PSNR Y> <R1 PSNR U> <R1 PSNR V>
     <R2 Bitrate> <R2 PSNR Y> <R2 PSNR U> <R2 PSNR V>
                            :                       
     <R5 Bitrate> <R5 PSNR Y> <R5 PSNR U> <R5 PSNR V>   

   Output: BD-PSNRs for Y, U, and V followed by BD-Rates for Y, U, and V as follows:
     
    <BD-PSNR Y> \t <BD-PSNR U> \t <BD-PSNR V> \t <BD-Rate Y> \t <BD-Rate U> \t <BD-Rate V>
   
*
*  Example
*  =======
	% cat anchor.txt
	 999.35 	33.01	39.27	40.32
	1598.99 	34.93	40.08	41.04
	2499.19 	36.69	40.97	41.89
	3996.57 	38.42	41.83	42.87
	5998.07 	39.79	42.47	43.66

	% cat proposal.txt
	 997.34 	34.68 	40.11 	41.13 
	1588.50 	36.64 	40.93 	41.96 
	2493.93 	38.34 	41.80 	42.92 
	3999.06 	39.99 	42.62 	43.93 
	5980.18 	41.00 	43.27 	44.77 

	% a.exe anchor.txt proposal.txt
	  1.628122 	  0.828040 	  0.993032 	-35.976930 	-36.433158 	-39.302836   

*
*  References
*  =======
	[1]	G. Bjontegaard, Calculation of Average PSNR Differences between RD curves, VCEG-M33, April 2001.
	[2]	G. Bjontegaard, Improvements of the BD-PSNR model, VCEG-AI11, July 2008. 
	[3]	S. Pateux, Tools for proposal evaluations, JCTVC-A031, April 2010.

*
*  Author 
*  =======
  Kenta SENZAKI (NEC corp.)
  k-senzaki@bp.jp.nec.com

*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#define mymax(a,b) (((a)>(b))?(a):(b))
#define mymin(a,b) (((a)<(b))?(a):(b))
#define DEFAULT_RATE_POINT 5
#define DEFAULT_NUM_COEFS  5
#define DEFAULT_COLUMN     4

/*
Integration for (N-1)-order polynomial f(x) with interval [s e].
f(x) = coef[0] + coef[1]x^1 + coef[2]x^2 + coef[3]x^3 + ... + coef[n-1]x^(n-1)
*/
double PolyIntegral(int n, double *coef, double s, double e)
{
	int i;
	double tmp=0.0;
	double ds=1.0;
	double de=1.0;
	for(i=0; i<=n; i++)
	{
		ds *= s;
		de *= e;
		tmp += coef[i]*(de - ds)/(i+1);
	}
	return tmp;
}

/* QR decomposition*/
void dgeqrf(int m, int n, double *a, double *r)
{
	// m: The number of row
	// n: The number of column
	int i,j,k;
	double tmp;
	for(i=0; i<n; i++)
	{
		tmp = 0.0;
		for(j=0; j<m; j++) tmp+=a[j*n+i]*a[j*n+i];
		r[i*n+i] = sqrt(tmp);

		for(j=0; j<m; j++)
		{
			a[j*n+i] /= r[i*n+i];
		}
		for(j=i+1; j<n; j++)
		{
			tmp = 0.0;
			for(k=0; k<m; k++)
				tmp += a[k*n+i]*a[k*n+j];
			r[i*n+j] = tmp;
			for(k=0; k<m; k++)
				a[k*n+j] -= tmp*a[k*n+i];
		}
	}
}
/* Solve Ax=b by using the result of dgeqrf. */
void dgeqrs(int m, int n, double *q, double *r, double *b, double *x)
{
	int i,j;
	double *c=(double *)malloc(sizeof(double)*n);
	for(i=0; i<n; i++) c[i] = 0.0;
	// c = Q'*b  
	for(i=0; i<m; i++)
	{
		for(j=0; j<n; j++)
		{
			c[j] += q[i*n+j]*b[i];
		}
	}
	// x = R\c
	for(i=n-1; i>=0; i--)
	{
		x[i] = c[i];
		for(j=i+1; j<n; j++)
		{
			x[i] -= r[i*n+j]*x[j];
		}
		x[i] /= r[i*n+i];
	}
}

/* Generate m-by-n Vandermonde matrix. */
void Vandermonde(int m, int n, double *v, double *vander)
{
	int i,j;
	for(i=0; i<m; i++)
	{
		vander[i*n] = 1.0;
		for(j=1; j<n; j++)
		{
			vander[i*n + j] = vander[i*n + j -1]*v[i];
		}
	}
}

double ComputeInterpolationPolynomialAndIntegral(int m, int n, double xmin, double xmax, double *dat_x, double *dat_y)
{
	int i;
	double v;
	double *vander;
	double *r;
	double *cof;
	double *x, *y;
	double offset;
	if ((vander = (double *)malloc(sizeof(double)*m*n))==NULL) exit(1);	
	if ((r      = (double *)malloc(sizeof(double)*m*n))==NULL) exit(1);
	if ((cof    = (double *)malloc(sizeof(double)*n))  ==NULL) exit(1);
	if ((x  = (double *)malloc(sizeof(double)*m))  ==NULL) exit(1);
	if ((y  = (double *)malloc(sizeof(double)*m))  ==NULL) exit(1);
	for(i=0; i<m*n; i++) r[i] = 0.0;
	/* Computing offset for data. */
	offset = (dat_x[0] + dat_x[m-1])/2;
	for(i=0; i<m; i++)
	{
		x[i] = dat_x[i] - offset;
	}
	/* Computing Vandermonde matrix*/
	Vandermonde(m, n, x, vander);
	/* Computing coefficients of polynomial. */
	dgeqrf(m, n, vander, r);
	dgeqrs(m, n, vander, r, dat_y, cof);

	v = PolyIntegral(n-1,cof,xmin-offset,xmax-offset);
	free(vander);
	free(r);
	free(cof);
	free(x);
	free(y);
	return v;
}

double NBJM(int m, int n, double xmin, double xmax, double *anc_x, double *anc_y, double *prp_x, double *prp_y)
{
	double anc_v, prp_v;
	anc_v = ComputeInterpolationPolynomialAndIntegral(m, n, xmin, xmax, anc_x, anc_y);
	prp_v = ComputeInterpolationPolynomialAndIntegral(m, n, xmin, xmax, prp_x, prp_y);
	return (prp_v - anc_v)/(xmax - xmin);
}


int main(int argc, char **argv)
{

	int col=DEFAULT_COLUMN;   /* "col" is the number of data column */
	int i, j, ii;
	int m=DEFAULT_RATE_POINT; /* "m" is the number of data points. */
	int n=DEFAULT_NUM_COEFS;  /* "n" is the number of coefficients of interpolation polynomial. */
	double d_s, d_e;
	double d_s1, d_e1, d_s2, d_e2;

	double *dat1, *dat2;
	double *bit1, *bit2;
	double *snr1, *snr2;
	double BD_PSNR[3], BD_Rate[3];
	FILE *fp;
	if(argc!=3)
	{
		printf("Usage: %s <Anchor data file> <Proposal data file>\n", argv[0]);
		printf("     : Each data file shall be the following format.");
		printf("       <R1 Bitrate> <R1 PSNR Y> <R1 PSNR U> <R1 PSNR V>\n");
		printf("       <R2 Bitrate> <R2 PSNR Y> <R2 PSNR U> <R2 PSNR V>\n"); 
		printf("                               :                       \n");
		printf("       <R5 Bitrate> <R5 PSNR Y> <R5 PSNR U> <R5 PSNR V>\n");
		exit(0);
	}

	if((dat1=(double *)malloc(sizeof(double)*m*col))==NULL) exit(0);
	if((dat2=(double *)malloc(sizeof(double)*m*col))==NULL) exit(0);
	if((bit1=(double *)malloc(sizeof(double)*m    ))==NULL) exit(0);
	if((bit2=(double *)malloc(sizeof(double)*m    ))==NULL) exit(0);
	if((snr1=(double *)malloc(sizeof(double)*m    ))==NULL) exit(0);
	if((snr2=(double *)malloc(sizeof(double)*m    ))==NULL) exit(0);


	fp = fopen(argv[1], "r");
	if(fp==NULL)
	{
		printf("!!ERROR!!\n");
		printf(" Cannot read data %s\n", argv[1]);
		exit(1);
	}
	for (i=0; i<m; i++) {
		for (j=0; j<col; j++)
			fscanf(fp, "%lf", &(dat1[i*col+j]));
	}
	fclose(fp);

	fp = fopen(argv[2], "r");
	if(fp==NULL)
	{
		printf("!!ERROR!!\n");
		printf(" Cannot read data %s\n", argv[2]);
		exit(1);
	}
	for (i=0; i<m; i++) {
		for (j=0; j<col; j++)
			fscanf(fp, "%lf", &(dat2[i*col+j]));
	}
	fclose(fp);

	/* Convert bitrate data to logarithm. */
	for(i=0; i<m; i++)
	{
		bit1[i] = log10(dat1[i*col]);
		bit2[i] = log10(dat2[i*col]);
	}

	for(ii=1; ii<col; ii++)
	{
		for(i=0; i<m; i++)
		{
			snr1[i] = dat1[i*col+ii];
			snr2[i] = dat2[i*col+ii];
		}

		{/* Computing BD-PSNR. */
			d_s1 = bit1[0]; d_e1 = bit1[0];
			d_s2 = bit2[0]; d_e2 = bit2[0];
			for(j=1; j<m; j++) 
			{
				d_s1 = mymin(d_s1, bit1[j]);
				d_e1 = mymax(d_e1, bit1[j]);
			}
			for(j=1; j<m; j++) 
			{
				d_s2 = mymin(d_s2, bit2[j]);
				d_e2 = mymax(d_e2, bit2[j]);
			}
			d_s = mymax(d_s1, d_s2);
			d_e = mymin(d_e1, d_e2);
			BD_PSNR[ii-1] = NBJM(m, n, d_s, d_e, bit1, snr1, bit2, snr2);
		}
		{/* Computing BD-Rate. */
			d_s1 = snr1[0]; d_e1 = snr1[0];
			d_s2 = snr2[0]; d_e2 = snr2[0];
			for(j=1; j<m; j++) 
			{
				d_s1 = mymin(d_s1, snr1[j]);
				d_e1 = mymax(d_e1, snr1[j]);
			}
			for(j=1; j<m; j++) 
			{
				d_s2 = mymin(d_s2, snr2[j]);
				d_e2 = mymax(d_e2, snr2[j]);
			}
			d_s = mymax(d_s1, d_s2);
			d_e = mymin(d_e1, d_e2);
			BD_Rate[ii-1] = (pow(10.0,NBJM(m, n, d_s, d_e, snr1, bit1, snr2, bit2))-1.0)*100;
		}
	}

	/* Output result. */
	for(ii=0; ii<col-1; ii++)
		printf("% 10.6lf \t", BD_PSNR[ii]);
	for(ii=0; ii<col-2; ii++)
		printf("% 10.6lf \t", BD_Rate[ii]);
	printf("% 10.6lf\n", BD_Rate[col-2]);

	free(dat1);
	free(dat2);
	free(bit1);
	free(bit2);
	free(snr1);
	free(snr2);
	return 0;
}
